my_name = "nejm"
my_address = "Kantry"

def disp_message():
	return "Moduł działa"
	
def display_message1():
	return "All about Python!"