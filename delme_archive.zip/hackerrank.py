#_Introduction
# 1 Say "Hello, World!" With Python
print("Hello, World!")



# 2 Python If-Else
if __name__ == '__main__':
    n = int(input().strip())
    if (n % 2 == 1) or 6 <= n <= 20:
        print("Weird")
    else:
        print("Not Weird")



# 3 Arithmetic Operators
if __name__ == '__main__':
    a = int(input())
    b = int(input())

    print(a + b, end="\n")
    print(a - b, end="\n")
    print(a * b)



# 4 Divison
if __name__ == '__main__':
    a = int(input())
    b = int(input())

    print('{} \n{}'.format((a//b), (a/b)))



# 5 Loops
if __name__ == '__main__':
    n = int(input())
    print(*[i**2 for i in range(n)], sep="\n")



# 6 Write a function
def is_leap(year):
    leap = False
    if year % 400 == 0:
        leap = True
    elif year % 4 == 0 and not year % 100 == 0:
        leap = True
    return leap
year = int(input())
print(is_leap(year))


def is_leap(year):
    return year % 4 == 0 and (year % 400 == 0 or year % 100 != 0)

year = int(input())
print(is_leap(year))



# 7 Print Function
if __name__ == '__main__':
    n = int(input())
    print(*[i for i in range(1, n + 1)], sep="")

if __name__ == '__main__':
    n = int(input())
    print(*list(range(1, n + 1)), sep="")

#Introduction






# Basic Data Types
# 8 List Comprehensions
if __name__ == '__main__':
    x, y, z, n = (int(input()) for _ in range(4))
    print([[i, j, k] for i in range(x + 1) for j in range(y + 1) for k in range(z + 1) if i + j + k != n])



# 9 Find the Runner-Up Score!
if __name__ == '__main__':
    # n = int(input()) # na co to?
    arr = map(int, input().split())
    arr = list(arr)
    # max_count = arr.count(max(arr))
    [arr.remove(max(arr)) for i in range(arr.count(max(arr)))]
    print(max(arr))

if __name__ == '__main__':
    # n = int(input())
    arr = map(int, input().split())
    arr = sorted(list(set(arr)))[-2]
    print(arr)



# 10 Nested Lists
if __name__ == '__main__':
    nasc = {}
    nasc2 = {}
    names = []
    for _ in range(int(input())):
        name = input()
        score = float(input())
        nasc[name] = score
    for key, val in nasc.items():
        if val != min(nasc.values()):
            nasc2[key] = val
    for key, val in nasc2.items():
        if val == min(nasc2.values()):
            names.append(key)
    for name in sorted(names):
        print(name, end="\n")

# to niżej nie działa, ale po coś było
if __name__ == '__main__':
    nasc = {}
    nasc2 = {}
    names = []
    
    for _ in range(int(input())):
        name = input()
        score = float(input())
        nasc[name] = score
    
    sort_val = {k: v for k, v in sorted(nasc.items(), key=lambda item: item[1])}

    for key, val in nasc.items():
        if val == sort_val:
            names.append(key)
    for name in sorted(names):
        print(name, end="\n")
    print(sort_val)




# 11 Finding the percentage
from statistics import mean as mean
if __name__ == '__main__':
    student_marks = {}
    for _ in range(int(input())):
        name, *line = input().split()
        scores = list(map(float, line))
        student_marks[name] = scores
    query_name = input()
    # print(round(mean(student_marks[query_name]), 2))
    print('{:.2f}'.format(round(mean(student_marks[query_name]), 2)))



# 12 Lists
if __name__ == '__main__':
    lis1 = []
    for _ in range(int(input())):
        #inp = input().split()
        #met, arg = inp[0], inp[1:]
        met, *arg = input().split()
        if met == "print":
            print(lis1)
        else:
            arg = ", ".join(arg)
            eval("lis1." + met + "(" + arg + ")")
        '''
        arg = ", ".join(arg)
        print("lis1." + met + "(" + arg + ")")
        '''



# 13 Tuples
if __name__ == '__main__':
    n = int(input())
    integer_list = map(int, input().split())
    print(hash(tuple(integer_list)))

# Basic Data Types






# Strings
# 14 sWAP cASE
def swap_case(s):
    new = ""
    for inp in s:
        if inp.isdigit() == False:
            if inp.isupper():
                new += inp.lower()
            else: 
                new += inp.upper()
        else:
            new += inp
    return(new)

if __name__ == '__main__':
    s = input()
    result = swap_case(s)
    print(result)


def swap_case(s):
    return "".join([i.lower() if i.isupper() else i.upper() for i in s])

def swap_case(s):
    return "".join(map(str.swapcase, s))

def swap_case(s):
    return s.swapcase()



# 15 String Split and Join
def split_and_join(line):
    return "-".join(line.split())

if __name__ == '__main__':
    line = input()
    result = split_and_join(line)
    print(result)

def split_and_join(line):
    return line.replace(" ", "-")



# 16 What's Your Name?
def print_full_name(first, last):
    print("Hello {} {}! You just delved into python.".format(first, last))

if __name__ == '__main__':
    first_name = input()
    last_name = input()
    print_full_name(first_name, last_name)



# 17 Mutations
# You are given an immutable string, and you want to make changes to it.
>>> string = "abracadabra"
>>> l = list(string)
>>> l[5] = 'k'
>>> string = ''.join(l)
>>> print string
abrackdabra

>>> string = string[:5] + "k" + string[6:]
>>> print string
abrackdabra

def mutate_string(string, position, character):
    return string[:position] + character + string[position + 1:]
    # li1 = list(string)
    # li1[position] = character
    # return "".join(li1)

if __name__ == '__main__':
    s = input()
    i, c = input().split()
    s_new = mutate_string(s, int(i), c)
    print(s_new)



# 18 Find a string
def count_substring(string, sub_string):
    counter = 0
    for i in range(len(string)):
        if sub_string == string[i:i + len(sub_string)]:
            counter += 1
    return counter

if __name__ == '__main__':
    string = input().strip()
    sub_string = input().strip()
    
    count = count_substring(string, sub_string)
    print(count)

def count_substring(string, sub_string):
    return len([i for i in range(len(string)) if sub_string == string[i:i + len(sub_string)]])



# 19 String Validators
if __name__ == '__main__':
    s = input()
    print(any(char.isalnum() for char in s))
    print(any(char.isalpha() for char in s))
    print(any(char.isdigit() for char in s))
    print(any(char.islower() for char in s))
    print(any(char.isupper() for char in s))
    


# 20 Text Alignment
print 'HackerRank'.ljust(width,'-')

#Replace all ______ with rjust, ljust or center. 

thickness = int(input()) #This must be an odd number
c = 'H'

#Top Cone
for i in range(thickness):
    print((c*i).rjust(thickness-1)+c+(c*i).ljust(thickness-1))

#Top Pillars
for i in range(thickness+1):
    print((c*thickness).center(thickness*2)+(c*thickness).center(thickness*6))

#Middle Belt
for i in range((thickness+1)//2):
    print((c*thickness*5).center(thickness*6))    

#Bottom Pillars
for i in range(thickness+1):
    print((c*thickness).center(thickness*2)+(c*thickness).center(thickness*6))    

#Bottom Cone
for i in range(thickness):
    print(((c*(thickness-i-1)).rjust(thickness)+c+(c*(thickness-i-1)).ljust(thickness)).rjust(thickness*6))



# 21 Text Wrap
import textwrap
def wrap(string, max_width):
    string2 = ""
    while len(string) > max_width:
        string2 += string[:max_width] + "\n"
        string = string[max_width:]
    string2 += string
    return string2

if __name__ == '__main__':
    string, max_width = input(), int(input())
    result = wrap(string, max_width)
    print(result)



# 22 Designer Door Mat
inp = int(input("Tylko pierwsza liczba ma znaczenie: ").split()[0])
div = inp//2
for i in range(div):
    print("-"*(div - i)*3 + "." + "|.."*i + "|" + "..|"*i + "." + 3*(div - i)*"-")
print("WELCOME".center(3*inp, "-"))
for i in range(div-1, -1, -1):
    print("-"*(div - i)*3 + "." + "|.."*i + "|" + "..|"*i + "." + 3*(div - i)*"-")

inp = int(input("Tylko pierwsza liczba ma znaczenie: ").split()[0])
div = inp//2
for i in range(div):
    print("-"*(div - i)*3 + ".|."*(2*i + 1) + 3*(div - i)*"-")
print("WELCOME".center(3*inp, "-"))
for i in range(div-1, -1, -1):
    print("-"*(div - i)*3 + ".|."*(2*i + 1) + 3*(div - i)*"-")

inp = int(input("Tylko pierwsza liczba ma znaczenie: ").split()[0])
print("\n".join([(".|."*(2*i + 1)).center(3*inp, "-") for i in range(inp//2)]))
print("WELCOME".center(3*inp, "-"))
print("\n".join([(".|."*(2*i + 1)).center(3*inp, "-") for i in range(inp//2-1, -1, -1)]))

inp = int(input("Tylko pierwsza liczba ma znaczenie: ").split()[0])
up = [(".|."*(2*i + 1)).center(3*inp, "-") for i in range(inp//2)]
middle = ["WELCOME".center(3*inp, "-")]
print("\n".join(up + middle + up[::-1]))

n, m = map(int, input().split())
pattern = [('.|.'*(2*i + 1)).center(m, '-') for i in range(n//2)]
print('\n'.join(pattern + ['WELCOME'.center(m, '-')] + pattern[::-1]))

names = ["Rick Sanchez", "Morty Smith", "Summer Smith", "Jerry Smith", "Beth Smith"]
names[::-1]



# 23 String Formatting
def print_formatted(number):
    str_len = len(bin(number)[2:])
    for i in range(1, number + 1):
        print("{}".format(i).rjust(str_len), end=' ')
        print("{}".format(oct(i)[2:]).rjust(str_len), end=' ')
        print("{}".format(hex(i)[2:]).upper().rjust(str_len), end=' ')
        print("{}".format(bin(i)[2:]).rjust(str_len))

if __name__ == '__main__':
    n = int(input())
    print_formatted(n)


def print_formatted(n):
    width = len("{:b}".format(n))
    for i in range(1, n + 1):
        print("{0:{width1}d} {0:{width1}o} {0:{width1}X} {0:{width1}b}".format(i, width1=width))

 

# 24 Alphabet Rangoli
n = 5
def print_rangoli(size):
    n = size
    char_list = [chr(c) for c in range(ord("a"), 97 + n)]
    char_list_r = char_list[::-1]
    
    for i in range(0, n):
        print("{}".format("-".join(char_list_r[0:1 + i] + char_list[n-i:n+1])).center(((n - 1)*2 + 1) + ((n - 1)*2), "-"))
    for i in range(n-2, -1, -1):
        print("{}".format("-".join(char_list_r[0:1 + i] + char_list[n-i:n+1])).center(((n - 1)*2 + 1) + ((n - 1)*2), "-"))


# char_list[2:-4:-1] + char_list[1:]
#[liczy od końca indeks początku inclusive:liczy od końca indeks końca listy exclusive:-1]
char_list_r[::-1]



# 25 Capitalize!
n = "sdfs sadf"
[i.capitalize() for i in n." ".join(split()]

s = input()
for x in s[:].split():
    s = s.replace(x, x.capitalize())
print(s)

a = "sdf sdfsd"
print(" ".join([i.capitalize() for i in a.split()]))



# Merge the Tools!
def merge_the_tools(string, k):
    for i in range(len(string)//k):
        str = string[k*i:k*(i + 1)]
        str2 = ''
        for st in str:
            if st not in str2: str2 += st
        print(str2)

if __name__ == '__main__':


Sample Input
STDIN       Function
-----       --------
AABCAAADA   s = 'AABCAAADA'
3           k = 3



# 


# String







# Sets
# 32 Introduction to Sets
def average(array):
    return sum(set(array))/len(set(array))

if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    result = average(arr)
    print(result)



# 32 Symmetric Difference
n = input()
n = set(map(int, input().split()))
m = input()
m = set(map(int, input().split()))
print(*sorted(m.difference(n).union(n.difference(m))), sep="\n")

Input (stdin)
4
2 4 5 9
4
2 4 11 12

n, n =input(), set(map(int, input().split()))
m, m =input(), set(map(int, input().split()))
print(*sorted(m.difference(n).union(n.difference(m))), sep="\n")

n, n =input(), set(map(int, input().split()))
m, m =input(), set(map(int, input().split()))
print(*sorted(n^m), sep="\n")



# 32 Set .add()
print(len({input() for i in range(int(input()))}))

Sample Input
7
UK
China
USA
France
New Zealand
UK
France 



# 32 Set .discard(), .remove() & .pop()
n = int(input())
s = set(map(int, input().split()))

for _ in range(int(input())):
    inp = input().split()
    met, arg = inp[0], "".join(inp[1:])
    eval("s." + met + "(" + arg + ")")
    
print(sum(s))


Sample Input
9
1 2 3 4 5 6 7 8 9
10
pop
remove 9
discard 9
discard 8
remove 7
pop 
discard 6
remove 5
pop 
discard 5


n = int(input())
s = set(map(int, input().split()))

for _ in range(int(input())):
    eval('s.{0}({1})'.format(*input().split()+[' ']))
print(sum(s))



# 32 Set .union() Operation
m, m = input(), set(input().split())
n, n = input(), set(input().split())
print(len(m|n))
#print(len(m.union(n)))

Sample Input
9
1 2 3 4 5 6 7 8 9
9
10 1 2 3 11 21 55 6 8



# 32 Set .intersection() Operation
_, m, _, n = input(), set(input().split()), input(), set(input().split())
print(len(m&n))
# print(len(m.intersection(n)))

Sample Input
9
1 2 3 4 5 6 7 8 9
9
10 1 2 3 11 21 55 6 8






# 32 Set .difference() Operation
_, m, _, n = input(), set(input().split()), input(), set(input().split())
print(len(m-n))
# print(len(m.intersection(n)))

Sample Input
9
1 2 3 4 5 6 7 8 9
9
10 1 2 3 11 21 55 6 8



# 32 Set .symmetric_difference() Operation
_, m, _, n = input(), set(input().split()), input(), set(input().split())
print(len(m^n))
# print(len(m.symmetric_difference(n)))

Sample Input
9
1 2 3 4 5 6 7 8 9
9
10 1 2 3 11 21 55 6 8



# 33 Set Mutations
H = set("Hacker")
R = set("Rank")
H|=R
#H.update(R)
print(H)

H&=R
# H.intersection_update(R)
print(H)

H-=R
# H.difference_update(R)
print(H)

H^=R
# H.symmetric_difference_update(R)
print(H)


_, s = input(), set(map(int, input().split()))
for _ in range(int(input())):
    met, _ = input().split()
    n = set(map(int, input().split()))
    eval("s. {}({})".format(met, n))
print(sum(s))

16
1 2 3 4 5 6 7 8 9 10 11 12 13 14 24 52
4
intersection_update 10
2 3 5 6 8 9 1 4 7 11
update 2
55 66
symmetric_difference_update 5
22 7 35 62 58
difference_update 7
11 22 35 55 58 62 66


_, s = input(), set(map(int, input().split()))
for _ in range(int(input())):
    eval("s. {0}({2})".format(*input().split(), set(map(int, input().split()))))
print(sum(s))



# 32 The Captain's Room
from collections import Counter
_ = input()
lis1 = Counter(list(map(int, input().split())))
print(min(lis1, key=lis1.get)) # get min value form list

Sample Input
5
1 2 3 6 5 4 4 2 5 3 6 1 6 5 3 2 4 1 2 5 1 4 3 6 8 4 3 1 5 6 2 

from collections import Counter
_ = input()
num = Counter(map(int, input().split()))
print(min(num, key=num.get))
# działa w 9/10
# print(list(num.keys())[-1])



```
from collections import Counter
_ = input()
num = Counter(map(int, input().split()))
print(num.most_common()[-1][0])
```

another one 
```
print(min(num, key=num.get))
```

this works 9/10
```
print(list(num.keys())[-1])
```

# 33 Check Subset
for _ in range(int(input())):
    _, m, _, n = input(), set(input()), input(), set(input())
    print(m.issubset(n))

Sample Input
3
5
1 2 3 5 6
9
9 8 5 6 3 2 1 4 7
1
2
5
3 6 5 4 1
7
1 2 3 5 6 8 9
3
9 8 2



# 33 Check Strict Superset

{"1", "2", "3"} > {"1", "2"}

m = set(input().split())
i = 0
ran = int(input())
for _ in range(ran):
    n = set(input().split())
    if n.issubset(m) and n != m:
        i += 1
print(i == ran)

Sample Input
1 2 3 4 5 6 7 8 9 10 11 12 23 45 84 78
2
1 2 3 4 5
100 11 12

m = set(input().split())
print(all(list([m > set(input().split()) for _ in range(int(input()))])))




# No Idea!
_, m = input().split()
li1, se1, se2 = input().split(), set(input().split()), set(input().split())
print(sum([((i in se1) - (i in se2)) for i in li1])))

Sample Input
3 2
1 5 3
3 1
5 7


# może i dobre ale wysypue się bo za długo liczy
_, m = input().split()
li1, se1, se2 = input().split(), list(set(input().split())), list(set(input().split())) 
suma = 0
for i in li1:
    if i in se1:
        suma += 1
    if i in se2:
        suma -= 1
print(suma)
#print(len(li1 & set(input().split())) - len(li1 & set(input().split())))

# Sets








# Math
# 25 Polar Coordinates
from math import sqrt
from cmath import phase
n = complex(input())
print(sqrt(n.real**2 + n.imag**2))
print(phase(n))
 


# 26 Mod Divmod
m, n = (int(input()) for _ in range(2))
print(m//n, m%n, (m//n, m%n), sep="\n")

Sample Input
177
10



# 26 Power - Mod Power
a, b, m = (int(input()) for _ in range(3))
print(a**b, pow(a, b, m), sep="\n")

Sample Input
3
4
5


# 26 Integers Come In All Sizes
a, b, c, d = (int(input()) for _ in range(4))
print(a**b + c**d)



# Find Angle MBC
import math as m
a, b = int(input()), int(input())
print(str(round(m.degrees(m.asin(a/m.sqrt(a**2 + b**2))))) + "\u00b0")


# Triangle Quest
for i in range(1, int(input())):
    print((i*10**i)//9)

Sample Input
5



# Triangle Quest 2
for i in range(1,int(input())+1): print("".join([str(j) for j in range(1, i)]) + "".join([str(j) for j in range(i, 0, -1)]))
[print("".join([str(j) for j in range(1, i)]) + "".join([str(j) for j in range(i, 0, -1)])) for i in range(1,int(input())+1)]


for i in range(1, int(input())+1):
    print(*(range(1, i)), *(range(i, 0, -1)), sep="")

Sample Input
5

for i in range(1, int(input())+1):
    print(((10**i)//9)**2)


# Math








#Itertools
# 26 itertools.product()
from itertools import product
A = map(int, input().split())
B = map(int, input().split())
for i in product(A, B):
    print(i, end=' ') 

from itertools import product
A = map(int, input().split())
B = map(int, input().split())
print(*product(A, B)) 



# 27 itertools.permutations()
# Enter your code here. Read input from STDIN. Print output to STDOUT
from itertools import permutations
inp, num = input().split()
inp = [i for i in inp]
num = int(num)
li1 = ["".join(i) for i in list(permutations(inp, num))]
li1.sort()
for i in range(len(li1)):
    print(li1[i])


from itertools import permutations
inp, num = input().split()
print(*["".join(i) for i in permutations(sorted(inp), int(num))], sep="\n")



# 28 itertools.combinations()
from itertools import combinations
inp, num = input().split()
for j in range(1, int(num) + 1):
    #for i in combinations(sorted(inp), j):
    #    print("".join(i))
    print(*["".join(i) for i in combinations(sorted(inp), j)], sep="\n")

        

# 29 itertools.combinations_with_replacement()
from itertools import combinations_with_replacement
inp, num = input().split()
print(*["".join(i) for i in list(combinations_with_replacement(sorted(inp), int(num)))], sep="\n")



# 30 Compress the String!
from itertools import groupby
data = "1222311"
for key, group in groupby(data, lambda x: x[0]):
    print("({1}, {0})".format(key, len(list(group))), end=" ")

print(*["({}, {})".format(len(list(group)), key) for key, group in groupby(data, lambda x: x[0])])

print(*[(len(list(group)), int(key)) for key, group in groupby(data)])



# Iterables and Iterators
from itertools import combinations
from statistics import mean
_, letters, k = int(input()), "".join(list(input().split())), int(input())
print(mean([True if 'a' in ''.join(i) else False for i in  combinations(letters, k)]))

Sample Input
4 
a a c d
2



# Maximize It!
from itertools import product
K, M = map(int, input().split())
li = [list(map(int, input().split()))[1:] for _ in range(K)]
print(max(map(lambda i: sum(j**2 for j in i)%M, list(product(*li)))))

Sample Input
3 1000
2 5 4
3 7 8 9 
5 5 7 8 9 10 


#Itertools








# Collections
# 31 collections.Counter()
from collections Counter
myList = [1,1,2,3,4,5,3,2,3,4,2,1,2,3]
list(Counter(myList).items())[0]



# Importing defaultdict
from collections import defaultdict
lst = [('Geeks', 1), ('For', 2), ('Geeks', 3)]
orDict = defaultdict(list)
# iterating over list of tuples
for key, val in lst:
    orDict[key].append(val)
print(orDict)



from collections import Counter, defaultdict

# n = int(input())
shoe_sizes = [2, 3, 4, 5, 6, 8, 7, 6, 5, 18]
# shoe_sizes = map(int, input().split())
shoe_size_count = Counter(shoe_sizes)
print(shoe_size_count)


order_list = [[6, 55], [6, 45], [6, 55], [4, 40], [18, 60], [10, 50]]
# order_list = [list(map(int, input().split())) for _ in range(int(input()))]
order_dict = defaultdict(list)
[order_dict[key].append(val) for key, val in order_list]
print(order_dict)


money = 0
for key, val in order_list:
    # if key in shoe_size_count.keys():
    if shoe_size_count[key]:
        money += order_dict[key][0]
        del order_dict[key][0]
        shoe_size_count[key] -= 1
        if shoe_size_count[key] == 0:
            del shoe_size_count[key]
        # shoe_size_count = {x: y for x, y in shoe_size_count.items() if y!=0}

print(money)


# numCust = int(input())
numCust = 6
money = 0
for i in range(numCust):
    size, price = map(int, input().split())
    if shoe_size_count[size]:
        money += price
        shoe_size_count[size] -= 1
print(money)




# 33 DefaultDict Tutorial
from collections import defaultdict
a = ['a', 'a', 'b', 'a', 'b']
b = ['a', 'b']
d = defaultdict(list)
for i in range(len(a)):
    d[a[i]].append(i)
for i in range(len(b)):
    if b[i] in d.keys():
        print(" ".join(d[b[i]])
    else:
        print(-1)


from collections import defaultdict
a = ['a', 'a', 'b', 'a', 'b']
b = ['a', 'b']
#m, n = list(map(int, input().split()))
#a = [input() for _ in range(m)]
#b = [input() for _ in range(n)]

d = defaultdict(list)
[d[a[i]].append(i + 1) for i in range(len(a))]

for i in b:
    if i in d.keys():
        print(*d[i])
    else:
        print(-1)



# 34 Collections.namedtuple()
from collections import namedtuple
from statistics import mean
n = int(input())
nt_templet = namedtuple("some_name", input())
print(mean([int(nt_templet(*input().split()).MARKS) for i in range(n)]))

Input (stdin)
5
ID         MARKS      NAME       CLASS
1          97         Raymond    7
2          50         Steven     4
3          91         Adrian     9
4          72         Stewart    5
5          80         Peter      6



# 35 collections.OrderedDict
# split form end
from collections import OrderedDict
dict1 = OrderedDict()
dict2 = OrderedDict()
for i in range(int(input())):
    inp1 = input().split()
    name, price = " ".join(inp1[:-1]), inp1[-1]
    dict1[name] = dict1.get(name, 0) + 1
    dict2[name] = price

for key, val in dict1.items():
    print(key, int(val) * int(dict2[key]))

Input (stdin)
9
BANANA FRIES 12
POTATO CHIPS 30
APPLE JUICE 10
CANDY 5
APPLE JUICE 10
CANDY 5
CANDY 5
CANDY 5
POTATO CHIPS 30

from collections import OrderedDict
dict1 = OrderedDict()
for _ in range(int(input())):
    name, space, price = input().rpartition(" ")
    dict1[name] = dict1.get(name, 0) + int(price)

[print(key, val) for key, val in dict1.items()]



# 36 Collections.deque()
from collections import deque
s = deque()

for _ in range(int(input())):
    # eval('s.{0}({1})'.format(*input().split()+[' ']))
    met, *arg = input().split()
    arg = ", ".join(arg)
    eval("s." + met + "(" + arg + ")")
    #print(arg)
print(*s)




# Word Order
from collections import OrderedDict
dict1 = OrderedDict()
for _ in range(int(input())):
    name = input()
    dict1[name] = dict1.get(name, 0) + 1
# print(len([i for i, j in dict1.items()]))
print(len(dict1))
#print(*[j for i, j in dict1.items()], sep=' ')
print(*list(dict1.values()), sep=' ')


Sample Input
4
bcdef
abcdefg
bcde
bcdef


from collections import Counter, OrderedDict
class OrderedCounter(Counter, OrderedDict):
    pass
d = OrderedCounter(input() for _ in range(int(input())))
print(len(d))
print(*d.values())



# Company Logo
#!/bin/python3

#!/bin/python3

import math
import os
import random
import re
import sys
from collections import Counter, OrderedDict
import itertools

if __name__ == '__main__':
    dict1 = OrderedDict()
    for i in input():
        dict1[i] = dict1.get(i, 0) + 1
    #sort_val = {k: v for k, v in sorted(dict1.items(), key=lambda item: item[1],reverse=True)}
    #for key, val in dict(itertools.islice(sort_val.items(), 3)).items():
    #    print(key, val)
    dict2 = sorted(sorted(dict1), key = dict1.get, reverse = True) # sort dict
    for i in dict2[:3]:
        print(i, dict1[i])

Sample Input 0
aabbbccde


#!/bin/python3

import math
import os
import random
import re
import sys
from collections import Counter, OrderedDict


if __name__ == '__main__':
    class OrderedCounter(Counter, OrderedDict):
        pass

    [print(*i) for i in OrderedCounter(sorted(input())).most_common(3)]



# Piling Up!
# nie kumama zadania


# Collections








# Date and Time
# 37 Calendar Module
import calendar
day = calendar.weekday(2015, 8, 5)
days = [i for i in calendar.day_name]
months = [i for i in calendar.month_name]
# print("The day on {} {}th {} was {}.".format(months[8], "5", 2015, days[day]))
print(days[day].upper())

import calendar
list(calendar.day_name)















# Errors and Exceptions
# 38 Exceptions
for i in range(int(input())):
    try:
        m, n = map(int, input().split())
        print(m//n)
    except ZeroDivisionError as e:
        print("Error Code:", e)
    except ValueError as e:
        print("Error Code:", e) 

Input (stdin)
3
1 0
2 $
3 1

for i in range(int(input())):
    try:
        m, n = map(int, input().split())
        print(m//n)
    except BaseException as e: #Exception
        print("Error Code:", e)



# 39 Incorrect Regex
import re
for i in range(int(input())):
    #inp = input()
    #if re.search(r"\*\+", inp):
    #    print(False)
    #else:
    #    print(True)
    ans = True
    try :
        re.compile(input())
    except: #re.error
        ans = False
    print(ans)

Input (stdin)
2
.*\+
.*+









# Built-Ins
# 40 Zipped!
A = [1,2,3]
B = [6,5,4]
print([A] + [B])
print(list(zip(*([A] + [B]))))


from statistics import mean
_, leng = input().split()
m = zip(*[list(map(float, input().split())) for i in range(int(leng))])
n = [mean(i) for i in m]
print(*n, sep="\n")


Sample Input
5 3
89 90 78 93 80
90 91 85 88 86  
91 92 83 89 90.5


from statistics import mean
_, leng = input().split()
m = [map(float, input().split()) for i in range(int(leng))]
n = [mean(i) for i in zip(*m)]
print(*n, sep="\n")



# 41 Input()
x, y = input().split()
print(eval(input().replace("x", x)) == int(y))

Sample Input
1 4
x**3 + x**2 + x + 1

x, y = map(int, input().split())
print(eval(input()) == y)

str1 = "A**2"
A = int(5)
print(eval(str1))



# 42 Python Evaluation
eval(input())



# 43 Any or All
_ = input()
n = list(map(int, input().split()))
zero = not any([True for i in n if i < 0])
pali = False
if zero:
    pali = any([True for i in n if str(i)[0] == str(i)[-1]])
print(all([zero, pali]))


5
12 9 61 5 14 



_ = input()
n = list(map(int, input().split()))
print(any([str(i)[0] == str(i)[-1] for i in n]) and all([i >= 0 for i in n]))


_ = input()
n = input().split()
print(any([i[0] == i[-1] for i in n]) and all([int(i) >= 0 for i in n]))



# Athlete Sort
import numpy as np
# array sort
a = np.array([[8, 2, -2], [-4, 1, 7], [6, 3, 9]])
print(a)
print(a[a[:, 1].argsort()])
print(a[np.argsort(a[:, 1])])
print(a[:, 1].argsort())
print(np.argsort(a[:, 1]))


https://docs.python.org/3/howto/sorting.html
student_tuples = [
    ('john', 'A', 15),
    ('jane', 'B', 12),
    ('dave', 'B', 10),
]
sorted(student_tuples, key=lambda student: student[2])


z hackerranka
N, M = map(int, input().split())
rows = [input() for _ in range(N)]
K = int(input())
for row in sorted(rows, key=lambda row: int(row.split()[K])):
    print(row)


ostateczny
n, m = map(int, input().split())
arr = [list(map(int, input().split())) for _ in range(n)]
k = int(input())
for i in sorted(arr, key=lambda student: student[k]):
    print(*i)



# ginortS
# sort string with characters and numbers
str1 = 'Sorting1234'
print(sorted(str1 , key=lambda x: (x.isdigit() and int(x)%2==0, x.isdigit(), x.isupper(), x.islower(), x)))
print(*sorted(input(), key=lambda x: (x.isdigit(), x.isdigit() and int(x)%2==0, x.isupper(), x.islower(), x)), sep='')
dir(str)


# Built-Ins








# Python Functionals
# 44 Map and Lambda Function
cube = lambda x: x**3

def fibonacci(n):
    n1, n2 = 0, 1
    fib_lilst = [0, 1]
    count = 0
    
    while count < n:
       nth = n1 + n2
       fib_lilst.append(nth)
       # update values
       n1 = n2
       n2 = nth
       count += 1
    return fib_lilst[:n]

if __name__ == '__main__':
    n = int(input())
    print(list(map(cube, fibonacci(n))))

Sample input
5


cube = lambda x: x**3

def fibonacci(n):
    fib_lilst = [0, 1][:n]
    
    if n > 2:
        for i in range(n-2):
            fib_lilst.append(fib_lilst[i] + fib_lilst[i + 1])
    return fib_lilst

if __name__ == '__main__':
    n = int(input())
    print(list(map(cube, fibonacci(n))))



def fibonacci(n):
    a,b = 0,1
    for i in range(n):
        yield a
        a,b = b,a+b










# Regex and Parsing



# 45 Detect Floating Point Number
import re
print(*[bool(re.match(r"^[+-]?\d*\.\d*$", input())) for _ in range(int(input()))], sep="\n")

4
4.0O0
-1.00
+4.54
SomeRandomStuff



# 46 Re.split()
regex_pattern = r"[,.]"

import re
print("\n".join(re.split(regex_pattern, input())))


Sample Input 0
100,000,000.000

regex_pattern = r"[,.]"
regex_pattern = r"[\D+]"



# 47 Group(), Groups() & Groupdict() 
import re
m = re.search(r"(\w(?!_))\1+", input())
print(m.group(1) if m else -1)

Input (stdin)
12345678910111213141516171820212223

r"(\d(?!_))\1+"



# 45 Re.findall() & Re.finditer() do poprawy
import re
m = re.findall(r'(?<=[bcdfghjklmnpqrstvwxys])[aeuioAEUIO]{2,}(?=[bcdfghjklmnpqrstvwxys])', input(), re.I)
print(*m, sep='\n') if m else print(-1)


Input (stdin)
rabcdeefgyYhFjkIoomnpOeorteeeeet

import re
con = "[bcdfghjklmnpqrstvwxys]"
m = re.findall(r'(?<=' + con + ')[aeuioAEUIO]{2,}(?=' + con + ')', input(), re.I)
print(*m, sep='\n') if m else print(-1)



# 46Re.start() & Re.end()
# na hackereanku nie na regexa, tylko re, czyli nie ma overlapped=True
import regex as re
s = "aaadaa"
wor = "aa"
matches = re.finditer(r'(?=(' + wor + '))', s, overlapped=True)
results = [(match.start(), match.start() + len(wor)) for match in matches]
print(*results, sep='\n') if results else print((-1, -1))


Input (stdin)
aaadaa
aa

import re
s, wor = input(), input()
print(*[(i.start(), i.start() + len(wor) - 1) for i in re.finditer('(?='+wor+')',s)], sep='\n')


import re
s, wor = input(), input()
matches = [(m.start(), m.start() + len(wor) - 1) for m in re.finditer('(?='+wor+')',s)]
print(*matches, sep='\n') if matches else print((-1, -1))



# 48 Validating Roman Numerals
import re
regex_pattern = r"^(?=[MDCLXVI])(M{0,3})(C[MD]|D?C{0,3})(X[CL]|L?X{0,3})(I[XV]|V?I{0,3})$"
print(str(bool(re.match(regex_pattern, input()))))


Sample Input
CDXXI


^(?=[MDCLXVI])M*C[MD]|D?C{0,3}X[CL]|L?X{0,3}I[XV]|V?I{0,3}$ - bez nawiasów nie łapie całości



# Validating phone numbers
import re
print(*["YES" if bool(re.match(r'^[987]\d{9}$', input())) else "NO" for _ in range(int(input()))], sep='\n')

Sample Input
2
9587456281
1252478965



# Validating and Parsing Email Addresses
import re
for _ in range(int(input())):
    name, email = input().split()
    result = bool(re.match(r'^<[A-Za-z](\w|-|\.|_)+@[A-Za-z]+\.[A-Za-z]{1,3}>$', email))
    if result: print(*(name, email), sep=' ')

Sample Input
2  
DEXTER <dexter@hotmail.com>
VIRUS <virus!@variable.:p>

result = bool(re.match(r'^<[a-z](\w|-|\.|_)+@[a-z]+\.[a-z]{1,3}>$', email, re.I))

# Hex Color Code
import re
for _ in range(int(input())):
    result = re.findall(r'#[\d|a-f]{3,6}(?=\)|,|;)', input(), re.I)
    if result: print(*result, sep='\n')

Sample Input
11
#BED
{
    color: #FfFdF8; background-color:#aef;
    font-size: 123px;
    background: -webkit-linear-gradient(top, #f9f9f9, #fff);
}
#Cab
{
    background-color: #ABC;
    border: 2px dashed #fff;
}   

r'(?<!^)#[\d|a-f]{3,6}'
r'[\s:](#[a-f0-9]{6}|#[a-f0-9]{3})'
r'(?<!^)(#(?:[\da-f]{3}){1,2})' # nie wiem jak to działa



# 

# Regex and Parsing







# Closures and Decorators
# 48 Standardize Mobile Number Using Decorators
def wrapper(f):
    def fun(l):
        n = [" ".join((i[-10:-5], i[-5:])) for i in l]
        n.sort()
        print(*["+91 " + i for i in n], sep="\n")
    return fun

@wrapper
def sort_phone(l):
    print(*sorted(l), sep='\n')

if __name__ == '__main__':
    l = [input() for _ in range(int(input()))]
    sort_phone(l) 


Sample Input
3
07895462130
919875641230
9195969878


def wrapper(f):
    def fun(l):
        f(["+91 "+c[-10:-5]+" "+c[-5:] for c in l])
    return fun













# Numpy
# 49 Arrays
import numpy

def arrays(arr):
    return numpy.array(arr[::-1], float)

arr = input().strip().split(' ')
result = arrays(arr)
print(result)


Sample  Input
1 2 3 4 -8 -10


return numpy.flipud(numpy.array(arr, float))



# 50 Shape and Reshape
import numpy
ar = numpy.array(input().strip().split(' '), int)
print(numpy.reshape(ar,(3, 3)))


Sample Input
1 2 3 4 5 6 7 8 9

import numpy
ar = numpy.array(input().strip().split(' '), int)
ar.shape = (3, 3)
print(ar)


import numpy
print(numpy.reshape(numpy.array(input().strip().split(' '), int), (3, 3)))


import numpy
print(numpy.array(input().strip().split(' '), int).reshape(3, 3))


import numpy
print(numpy.array(list(map(int, input().split()))).reshape(3, 3))



# 51 Transpose and Flatten
import numpy
rows, cols = map(int, input().strip().split())
n = numpy.array([list(map(int, input().strip().split(' '))) for _ in range(rows)])
print(n.transpose())
print(n.flatten())


Sample Input
2 2
1 2
3 4



# 52 Concatenate
import numpy
n, m, _ = map(int, input().strip().split())
a1 = numpy.array([input().strip().split(' ') for _ in range(n)], int)
a2 = numpy.array([input().strip().split(' ') for _ in range(m)], int)
print(numpy.concatenate((a1, a2)))


Sample Input
4 3 2
1 2
1 2 
1 2
1 2
3 4
3 4
3 4 



# 53 Zeros and Ones
import numpy
n = list(map(int, input().strip().split()))
print(numpy.zeros(n, int))
print(numpy.ones(n, int))

Sample Input 0
3 3 3


import numpy
n = tuple(map(int, input().strip().split()))
print(numpy.zeros(n, int))
print(numpy.ones(n, int))



# 54 Eye and Identity
import numpy
numpy.set_printoptions(legacy='1.13')
n = tuple(map(int, input().strip().split()))
print(numpy.eye(n[0], n[1]))


Sample Input
3 3


import numpy
numpy.set_printoptions(legacy='1.13')
#n = tuple(map(int, input().strip().split()))
print(numpy.eye(*map(int, input().strip().split())))



# 55 Array Mathematics
# ten kod nie działa, bo za mało nawiasów generuje
import numpy
_ = input()
a = numpy.array(input().strip().split(' '), int)
b = numpy.array(input().strip().split(' '), int)
# a, b = [numpy.array(input().strip().split(' '), int) for _ in range(2)]
print(numpy.array(a+b), numpy.array(a-b), sep='\n')
print(a+b, a-b, a*b, a//b, a%b, a**b, sep='\n')


Sample Input
1 4
1 2 3 4
5 6 7 8


import numpy as np
n, m = map(int, input().split())
a, b = (np.array([input().split() for _ in range(n)], dtype=int) for _ in range(2))
print(a+b, a-b, a*b, a//b, a%b, a**b, sep='\n')



# 56 Floor, Ceil and Rint
import numpy
numpy.set_printoptions(legacy='1.13')
arr = numpy.array(input().strip().split(), float)
print(numpy.floor(arr), numpy.ceil(arr), numpy.rint(arr), sep='\n')


Sample Input
1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8 9.9



# 57 Sum and Prod
import numpy
n, _ = input().strip().split()
print(numpy.prod(numpy.sum(numpy.array([input().strip().split() for _ in range(int(n))], int), axis=0)))


Sample Input
2 2
1 2
3 4



# 58 Min and Max
import numpy
n, _ = input().strip().split()
ar = numpy.array([input().strip().split() for _ in range(int(n))], int)
print(max(numpy.min(ar, axis=1)))


Sample Input
4 2
2 5
3 7
1 3
4 0



# 59 Mean, Var, and Std
import numpy
n, _ = input().strip().split()
ar = numpy.array([input().strip().split() for _ in range(int(n))], int)
print(numpy.mean(ar, axis=1), numpy.var(ar, axis=0), round(numpy.std(ar), 11), sep='\n')

Sample Input
2 2
1 2
3 4



# 60 Dot and Cross
import numpy
n = int(input().strip())
ar1, ar2 = [numpy.array([input().strip().split() for _ in range(n)], int) for _ in range(2)]
print(numpy.dot(ar1, ar2))

Sample Input
2
1 2
3 4
1 2
3 4



# 61 Inner and Outer
import numpy
a, b = numpy.array([input().strip().split() for _ in range(2)], int)
print(numpy.dot(a, b))
print(numpy.outer(a, b))

Sample Input
0 1
2 3



# 62 Polynomials
import numpy
print(numpy.polyval(list(map(float, input().split())), float(input())))

Sample Input
1.1 2 3
0



# 63 Linear Algebra
import numpy
ar = numpy.array([input().strip().split() for _ in range(int(input()))], float)
print(round(numpy.linalg.det(ar), 2))


Sample Input
2
1.1 1.1
1.1 1.1

# Numpy










# XML 1 - Find the Score

import sys
import xml.etree.ElementTree as etree

def get_attr_number(node):
     return sum([len(elem.items()) for elem in tree.iter()])

if __name__ == '__main__':
    sys.stdin.readline()
    xml = sys.stdin.read()
    tree = etree.ElementTree(etree.fromstring(xml))
    root = tree.getroot()
    print get_attr_number(root)






# The HackerRank Interview Preparation Kit

# Warm-up Challenges

#1 Sales by Match
#!/bin/python3

import os
from collections import Counter

#
# Complete the 'sockMerchant' function below.
#
# The function is expected to return an INTEGER.
# The function accepts following parameters:
#  1. INTEGER n
#  2. INTEGER_ARRAY ar
#

def sockMerchant(n, ar):
    return sum([i//2 for i in list(Counter(ar).values())])

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    n = int(input().strip())

    ar = list(map(int, input().rstrip().split()))

    result = sockMerchant(n, ar)
    #print(list(result))

    fptr.write(str(result) + '\n')

    fptr.close()




#2 Counting Valleys
path = list('UDDDUDUU')
path = list('DDUUDDUDUUUD')
lvl = 0
vall = 0
for i in path:
    if i == "U":
        lvl+=1
    if i == "D":
        lvl-=1
        if lvl == -1:
            vall+=1
print(vall)

'''
_/\      _
   \    /
    \/\/

_          /\_
 \  /\    /
  \/  \/\/
'''




#3 Jumping on the Clouds
#c = [0, 0, 0, 0, 1, 0]
c = [0, 0, 1, 0, 0, 1, 0]
#c = [0, 0, 0, 1, 0, 0]
print(len(c)-3)
i = 0
count = 0
while i <= len(c)-3:
    if c[i+1] == 0 and c[i+2] == 0:
        i+=2
        count+=1
    elif c[i+1] == 1 and c[i+2] == 0:
        i+=2
        count+=1
    elif c[i+1] == 0:
        i+=1
        count+=1
if i != len(c) - 1: count+=1
print(count)
print(i)

# 6-3=3 
# i0 i2 c1
# i2 i3 c2
# i3 i5 c3
#
# 7-3=4
# i0 i1 c1
# i1 i3 c2
# i3 i4 c3
# i4 i6 c4
#
# 6-3=3
# i0 i2 c1
# i2 i4 c2
# i4

i = 0
count = 0
while i < len(c)-2:
    if c[i+2] == 0:
        i+=2
        count+=1
    else:
        i+=1
        count+=1
if i != len(c) - 1: count+=1        
print(count)
print(i)




# Repeated String
s = 'ab'
n = 9

count2 = s.count('a') * (n//len(s)) + s[:n%len(s)].count('a')

print(count2)





# Arrays
# 2D Array - DS

arr = [[1, 1, 1, 0, 0, 0], [0, 1, 0, 0, 0, 0], [1, 1, 1, 0, 0, 0], [0, 0, 2, 4, 4, 0], [0, 0, 0, 2, 0, 0], [0, 0, 1, 2, 4, 0]]
print(max([arr[i][j]+arr[i][j+1]+arr[i][j+2]+arr[i+1][j+1]+arr[i+2][j]+arr[i+2][j+1]+arr[i+2][j+2] for i in range(4) for j in range(4)]))

import numpy as np
print(max([sum(sum(arr[i+0:i+3, j+0:j+3]) - arr[1+i, 0+j] - arr[1+i, 2+j]) for i in range(4) for j in range(4)]))




# Arrays: Left Rotation
d = 4
a = [1, 2, 3, 4, 5]

print(a[d:] + a[:d])




# New Year Chaos

q = [2, 1, 5, 3, 4]
q = [2, 3, 5, 1, 4]
q = [5, 1, 2, 3, 7, 8, 6, 4]
#q = [1, 2, 5, 3, 7, 8, 6, 4]
#print(q)

def minimumBribes(q):
    swap = 0
    # for i in range(len(q)-1, -1, -1):
    for i in range(len(q)):
        # print(q[i], (i + 1))
        if q[i] > (i + 1) + 2:
            swap = 'Too chaotic'
            #print('Too chaotic')
            return print('Too chaotic')
        for j in range(max(0, q[i] - 2), i):
            if q[j] > q[i]:
                swap += 1
    return print(swap)

#print(minimumBribes(q))
minimumBribes(q)

        
        

# Minimum Swaps 2
q = [2, 1, 5, 3, 4]
#q = [2, 3, 5, 1, 4]
q = [5, 1, 2, 3, 7, 8, 6, 4]
#q = [1, 2, 5, 3, 7, 8, 6, 4]
q = [7, 1, 3, 2, 4, 5, 6]
q = [4, 3, 1, 2]


print(q)
def minimumSwaps(q):
    swap = 0
    i = 0
    while i < len(q):
        if q[i] != i + 1:
            tmp = q[i]
            print(tmp)
            print(q[q[i] - 1])
            q[i], q[tmp - 1] = q[tmp - 1], tmp
            print(q)
            swap += 1
        else:
            i += 1
    return print(swap)

#print(minimumBribes(q))
minimumSwaps(q)
        



# Array Manipulation
import collections
from typing import Collection


from collections import Counter
a = [[1, 2, 100], [2, 5, 100], [3, 4, 100]]

def arrayManipulation(n, queries):
    arr = [0] * n
    for i in range(len(queries)):
        for j in range(queries[i][0] - 1 , queries[i][1]):
            arr[j] += queries[i][2]
    return print(max(arr))


arrayManipulation(5, a)




# Dictionaries and Hashmaps
# Hash Tables: Ransom Note
from collections import Counter
def checkMagazine(magazine, note):
    note_counter = Counter(note)
    mag_counter = Counter(magazine)
    # print("Yes" if all([mag_counter[key] >= note_counter[key] for key, val in note_counter.items()]) else "No")
    print("Yes" if Counter(note) - Counter(magazine) == {} else "No")

checkMagazine('give me one grand today night'.rstrip().split(),'dup give one grand today'.rstrip().split())




# Two Strings
from collections import Counter
s1 = 'hello'
s2 = 'world'

def twoStrings(s1, s2):
    return print("YES" if Counter(s1) & Counter(s2) != {} else "NO")

twoStrings(s1, s2)




# Sherlock and Anagrams
# moszna
from collections import Counter
s = 'abba'
s = 'cdcd'
s = 'ifailuhkqq'
#s = 'kkkk'

'''
for i in range(1, 4):
    for j in range(i):
        print(i, j)
'''

def sherlockAndAnagrams(s):
    count = 0
    for i in range(1, len(s)):
        for j in range(i-1, -1, -1):
            print(i, j)
            print(s[j:i], s[j+1:])
            #for k in range(len(s[j+1:]) - len(s[j:i]) + 1):
            #   print(k, s[k:k+i])
            for k in range(len(s[j+1:])):
                if Counter(s[j:i]) == Counter(s[j+1:][k:k + len(s[j:i])]):
                    count += 1
    return count

print(sherlockAndAnagrams(s))
#sherlockAndAnagrams(s)


# Ten jest szybszy i penie lepiej działa
def sherlockAndAnagrams(s):
    count = Counter(("".join(sorted(s[j:j+i])) for i in range(1, len(s)) for j in range(len(s)-i+1)))
    return sum(sum(range(i)) for i in count.values())




# Count Triplets 
# moszna
from itertools import combinations
from collections import Counter
arr = [1, 2, 2, 4]
arr = [1, 5, 5, 25, 125]
r = 5

def countTriplets(arr, r):
    counter = 0
    for i in combinations(arr, 3):
        if len(set(i)) == 3 or set((1, 1)) == {1}:
            #print(list(map(lambda x: x/i[0], i)), end='')
            if list(map(lambda x: x/i[0], i)) == [1, r, r*r]:
                counter += 1
            #print(list(map(lambda x: x/i[0], i)))
    return counter

print(countTriplets(arr, r))

for i in combinations(arr, 3):
    print(set(i))

print(set((1, 1)) == {1})


# zajebane z hackerranka
def countTriplets(arr, r):
    a = Counter(arr)
    b = Counter()
    c = Counter()
    s = 0
    for i in arr:
        print(i)
        j = i//r
        print(j)
        k = i*r
        a[i]-=1
        print(b[j])
        if b[j] and a[k] and not i%r:
            s+=b[j]*a[k]
        b[i]+=1
        print()
    return b

print(countTriplets(arr, r))




# Sorting
# Sorting: Bubble Sort
a = [3, 2, 1]
a = [1, 2, 3]

def countSwaps(a):
    counter = 0
    for i in range(1, len(a)):
        for j in range(i):
            if a[i] < a[j]:
                print(a)
                a[j], a[i] = a[i], a[j]
                counter += 1
    print('Array is sorted in {} swaps.\nFirst Element: {}\nLast Element: {}'.format(counter, a[0], a[-1]))
    return

print(countSwaps(a))




# Mark and Toys
prices = [1, 12, 5, 111, 200, 1000, 10]
k = 50

def maximumToys(prices, k):
    items = 0
    ind = 0
    prices = sorted(prices)
    while items + prices[ind] <= k:
        items += prices[ind]
        ind += 1
    return ind

print(maximumToys(prices, k))




# Sorting: Comparator

