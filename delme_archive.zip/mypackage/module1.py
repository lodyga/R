def mod1_func1():
    print("Welcome to Module1 function1")

def mod1_func2():
    print("Welcome to Module1 function2")

def mod1_func3():
    print("Welcome to Module1 function3")