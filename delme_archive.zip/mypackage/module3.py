def mod3_func1():
    print("Welcome to Module3 function1")

def mod3_func2():
    print("Welcome to Module3 function2")

def mod3_func3():
    print("Welcome to Module3 function3")