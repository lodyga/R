def mod2_func1():
    print("Welcome to Module2 function1")

def mod2_func2():
    print("Welcome to Module2 function2")

def mod2_func3():
    print("Welcome to Module2 function3")